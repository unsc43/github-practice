﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TowardsAStateMachine
{
    /// <summary>
    /// Enumeration to hold the possible values for the STATE Machine
    /// </summary>
    enum State
    {
        MOVE_ACROSSBOTTOM,
        MOVE_ACROSSTOP,
        MOVE_DOWN,
        MOVE_UP,
        REACHED_END, 
        PAUSE
    }
}
