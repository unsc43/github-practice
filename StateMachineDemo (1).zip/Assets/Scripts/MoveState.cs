﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace TowardsAStateMachine
{
    /// <summary>
    /// Base and derived classes to handle specialized movement to draw the rectangle.
    /// Fields defined in the MoveState class are common to all of the derived classes,
    /// which is why they are public.
    /// </summary>
    class MoveState
    {
        /// <summary>
        /// The currentPosition for the derived class can be X or Y depending
        /// upon the direction
        /// </summary>
        protected int currentPosition;

        /// <summary>
        /// The left or right boundary that the Move method of the derived class must stop at.
        /// </summary>
        protected int maxPosition;

        protected GameObject[] childObjects = null;

        protected Transform transformToMove;

        public MoveState(GameObject Wall, Transform transformToMove)
        {

            this.transformToMove = transformToMove;

            childObjects = new GameObject[Wall.transform.childCount];
            for (int i = 0; i < childObjects.Length; i++)
                childObjects[i] = Wall.transform.GetChild(i).gameObject;

            maxPosition = childObjects.Length;
        }

        /// <summary>
        /// Move the character marker as long as it is possible.
        /// 
        /// </summary>
        /// <returns>True when the marker can be advanced, false otherwise</returns>
        public virtual bool Move()
        {
            return false;
        }
    }


    /// <summary>
    ///  Derived MoveState class to handle moving left to right along the 
    ///  top boundary
    /// </summary>
    class MoveAcrossTop : MoveState
    {
        private float zPosition;
        /// <summary>
        /// Constructor passes parameters to the base class
        /// </summary>
        /// <param name="horizBoundary">The right boundary</param>
        /// <param name="vertBoundary">The top boundary</param>
        public MoveAcrossTop(GameObject Wall, Transform transformToMove) : base(Wall, transformToMove)
        {
            zPosition = transformToMove.position.x + 1;
        }

        /// <summary>
        /// Move in a right-most manner up until the right boundary.
        /// With every move print an "X" and advance the currentPosition field
        /// </summary>
        /// <returns>True if the currentPosition is less then (to the left of) the
        /// right boundary</returns>
        public override bool Move()
        {
            if (currentPosition < maxPosition)
            {
                Vector3 currentSpotlightPosition = transformToMove.position;
                float nextX = childObjects[currentPosition].transform.localPosition.x;
                Vector3 nextSpotlightPosition = new Vector3(nextX, currentSpotlightPosition.y, zPosition);
                transformToMove.position = nextSpotlightPosition;

                currentPosition++;
            }
            return currentPosition < maxPosition;

        }

    }

    /// <summary>
    /// Derived MoveState class to handle moving down the right boundary
    /// </summary>
    class MoveDown : MoveState
    {
        private float xPosition;
        /// <summary>
        /// Constructor passes parameters to the base class
        /// </summary>
        /// <param name="horizBoundary">The right boundary</param>
        /// <param name="vertBoundary">The bottom boundary</param>

        public MoveDown(GameObject Wall, Transform transformToMove) : base(Wall, transformToMove)
        {
            xPosition = transformToMove.position.x + 1;
        }
        /// <summary>
        /// Move from the top along the left boundary until the bottom boundary.
        /// With every move print an "X" and advance the currentPosition field
        /// </summary>
        /// <returns>True if the currentPosition is less then the bottom boundary
        /// right boundary</returns>
        /// <param name="horizBoundary">The right boundary</param>
        /// <param name="vertBoundary">The bottom boundary</param>
        public override bool Move()
        {
            if (currentPosition < maxPosition)
            {
                Vector3 currentSpotlightPosition = transformToMove.position;
                float nextZ = childObjects[currentPosition].transform.localPosition.x;
                Vector3 nextSpotlightPosition = new Vector3(xPosition, currentSpotlightPosition.y, nextZ);
                transformToMove.position = nextSpotlightPosition;

                Debug.Log(transformToMove.position);

                currentPosition++;
            }
            return currentPosition < maxPosition;

        }

    }

    /// <summary>
    ///  Derived MoveState class to handle moving right to left along the 
    ///  bottom boundary
    /// </summary>
    class MoveAcrossBottom : MoveState
    {
        private float zPosition;
        /// <summary>   
        /// Constructor passes parameters to the base class
        /// </summary>
        /// <summary>
        public MoveAcrossBottom(GameObject Wall, Transform transformToMove) : base(Wall, transformToMove)
        {
            zPosition = childObjects.First().transform.position.z;
        }
        /// Move in left-most manner up until the left boundary.
        /// With every move print an "X" and advance the currentPosition field
        /// </summary>
        /// <returns>True if the currentPosition is less then (to the right of) the
        /// left boundary</returns>
        public override bool Move()
        {
            if (currentPosition < maxPosition)
            {
                Vector3 currentSpotlightPosition = transformToMove.position;
                float nextX = childObjects[currentPosition].transform.localPosition.x;
                Vector3 nextSpotlightPosition = new Vector3(nextX, currentSpotlightPosition.y, zPosition);
                transformToMove.position = nextSpotlightPosition;
                

                currentPosition++;
                return true;
            }

            

            return false;

        }


    }

    /// <summary>
    /// Derived MoveState class to handle moving up the left boundary
    /// </summary>
    class MoveUp : MoveState
    {
        private float xPosition;
        /// <summary>
        /// Constructor passes parameters to the base class
        /// </summary>
        /// <param name="horizBoundary">The left boundary</param>
        /// <param name="vertBoundary">The top boundary</param>
        public MoveUp(GameObject Wall, Transform transformToMove) : base(Wall, transformToMove)
        {
            xPosition = transformToMove.position.x - 1;
        }

        /// <summary>
        /// Move  up until the top boundary.
        /// With every move print an "X" and advance the currentPosition field
        /// </summary>
        /// <returns>True if the currentPosition is less then the
        /// top boundary</returns>
        public override bool Move()
        {
            if (currentPosition < maxPosition)
            {

                Vector3 currentSpotlightPosition = transformToMove.position;
                float nextZ = childObjects[currentPosition].transform.localPosition.x;
                Vector3 nextSpotlightPosition = new Vector3(xPosition, currentSpotlightPosition.y, nextZ);
                transformToMove.position = nextSpotlightPosition;

                currentPosition++;
                return true;
            }
            return false;

        }


    }

}
