﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TowardsAStateMachine;

public class SpotLightController : MonoBehaviour
{
    
    [SerializeField]
    private GameObject[] Walls;

    [Header("Speed in milliseconds")]
    [SerializeField]
    private int Speed;

    private float waitTime = .1f;
    private float timer = 0.1f;

    private StateMachine stateMachine ;

    

    // Start is called before the first frame update
    void Start()
    {
        int count = Walls.Length;
        waitTime = Speed / 1000f;
        stateMachine = new StateMachine(Walls, this.transform, transform);
    }

    // Update is called once per frame
    void Update()
    {
        //TODO: If the user hits the Space Bar then set stateMachine.Halt to true
        //TODO: If the user hits the R key then set stateMachine.Halt to false

        timer += Time.deltaTime;

        if (timer > waitTime)
        {
            if (stateMachine.MoveLight())
                timer -= waitTime;
        }

    }
}
