﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace TowardsAStateMachine
{
    class StateMachine
    {

        private Transform InitialSpotlightPosition;

        private Transform transformToMove;


        /// <summary>
        /// Constructor initializes the SleepInterval field
        /// </summary>
        /// <param name="sleepInterval">SleepInterval value supplied by the calling method</param>
        public StateMachine(GameObject[] Walls,
            Transform transformToMove, Transform initialSpotlightPosition)
        {
            this.transformToMove = transformToMove;
            this.InitialSpotlightPosition = initialSpotlightPosition;
            AssignWalls(Walls);
        }

        private State lastStateBeforeHalt = State.MOVE_ACROSSBOTTOM;
        private bool _halt;
        
        public bool Halt
        {
            get { return _halt; }
            set { 
                // TODO: Explain in writing how this logic works
                if (_halt && value == false)
                {
                    state = lastStateBeforeHalt;
                }
                else if (!_halt && value == true)
                {
                    lastStateBeforeHalt = state;
                    state = State.PAUSE;
                }

                _halt = value; 
            
            }
        }

        private State state = State.MOVE_ACROSSBOTTOM;
        private MoveState moveState = null;
        private GameObject TopWall = null;
        private GameObject BottomWall = null;
        private GameObject RightWall = null;
        private GameObject LeftWall = null;
        

        private void AssignWalls(GameObject[] Walls)
        {

            for (int i = 0; i < Walls.Length && TopWall == null; i++)
            {
                if (Walls[i].tag == "TopWall")
                    TopWall = Walls[i];
            }
            for (int i = 0; i < Walls.Length && BottomWall == null; i++)
            {
                if (Walls[i].tag == "BottomWall")
                    BottomWall = Walls[i];
            }
            for (int i = 0; i < Walls.Length && RightWall == null; i++)
            {
                if (Walls[i].tag == "RightWall")
                    RightWall = Walls[i];
            }
            for (int i = 0; i < Walls.Length && LeftWall == null; i++)
            {
                if (Walls[i].tag == "LeftWall")
                    LeftWall = Walls[i];
            }
            moveState = new MoveAcrossBottom(BottomWall, transformToMove);
        }


        /// <summary>
        /// Draw the rectangle from left->right, up->down (right boundary),
        /// right->left (along the bottom) and finally down->up (left boundary 
        /// until the starting point is reached)
        /// The state changes after the moveState.Move can no longer move
        /// the position of the character marker ("X").
        /// Each move method moves the character marker in the correct manner
        /// for the type of state that the State Machine is currrently in.
        /// The State Machine, this method, does not have to concern itself
        /// with checking boundaries and how the row (X) and column (Y) 
        /// values change.
        /// Initially the StateMachine proceeds across the top from left to right.
        /// </summary>
        ///<param name="transformToMove">Reference to the spotlight transform</param>        
        public bool MoveLight()
        {
            bool AddTimer = true;
            switch (state)
            {
                //TODO: Check for State.Pause and if that is the case then MoveLight does nothing

                // Across the bottom, left to right
                case State.MOVE_ACROSSBOTTOM:
                    if (!moveState.Move())
                    {
                        // Switch to the next state as no more moves are 
                        // possible in this direction
                        state = State.MOVE_UP;
                        moveState = new MoveUp(RightWall, transformToMove);
                        AddTimer = false;
                    }
                    break;
                // Along the right boundary, from bottom to top
                case State.MOVE_UP:
                    if (!moveState.Move())
                    {
                        // Change the state to REACHED_END as there
                        // are no more possible moves aside from repeating the cycle.

                        state = State.MOVE_ACROSSTOP;
                        moveState = new MoveAcrossTop(TopWall, transformToMove);
                        AddTimer = false;
                    }
                    break;
                // Across the top, right to left
                case State.MOVE_ACROSSTOP:
                    if (!moveState.Move())
                    {
                        // Switch to the next state as no more moves are 
                        // possible in this direction
                        state = State.MOVE_DOWN;
                        moveState = new MoveDown(LeftWall, transformToMove);
                        AddTimer = false;
                    }
                    break;
                // Along the left boundary, from top to bottom
                case State.MOVE_DOWN:
                    if (!moveState.Move())
                    {
                        // Switch to the next state as no more moves are 
                        // possible in this direction
                        state = State.MOVE_ACROSSBOTTOM;
                        moveState = new MoveAcrossBottom(BottomWall, transformToMove);
                        AddTimer = false;
                    }
                    break;
                default:
                    break;
            }
            return AddTimer;
        }
    }
}
